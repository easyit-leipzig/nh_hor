<?php
declare(strict_types=1);

/**
 * Diese Datei nach database.local.php kopieren und nur auf dem Zielserver pflegen.
 * database.local.php wird durch .gitignore und .htaccess geschützt.
 */
return [
    'dsn' => 'mysql:host=localhost;dbname=DATENBANKNAME;charset=utf8mb4',
    'user' => 'DATENBANKBENUTZER',
    'password' => 'DATENBANKPASSWORT',
];
