<?php
declare(strict_types=1);

/**
 * Diese Datei nach site.local.php kopieren und nur auf dem Zielserver pflegen.
 * Keine vertraulichen oder serverbezogenen Werte versionieren.
 */
return [
    'phone' => '', // Reale Telefonnummer eintragen, z. B. +49 ...
    'email' => 'info@easyit-leipzig.de',
    'service_area' => 'Leipzig',
    'postal_address' => [
        'streetAddress' => '',
        'postalCode' => '',
        'addressLocality' => 'Leipzig',
        'addressRegion' => 'Sachsen',
        'addressCountry' => 'DE',
    ],
    'price_range' => '',
    'opening_hours' => [
        // Beispiel nach realen Zeiten anpassen:
        // ['@type' => 'OpeningHoursSpecification', 'dayOfWeek' => ['Monday', 'Tuesday'], 'opens' => '14:00', 'closes' => '19:00'],
    ],
    'geo' => [
        // 'latitude' => 51.3397,
        // 'longitude' => 12.3731,
    ],
    'same_as' => [
        // Nur offizielle, öffentlich sichtbare Profile eintragen.
    ],
];
