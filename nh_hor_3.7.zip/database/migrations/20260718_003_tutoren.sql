USE easyit;

CREATE TABLE IF NOT EXISTS tutors (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    slug VARCHAR(160) NOT NULL,
    display_name VARCHAR(160) NOT NULL,
    professional_title VARCHAR(190) NOT NULL,
    short_intro TEXT NOT NULL,
    biography TEXT NOT NULL,
    teaching_approach TEXT NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    image_alt VARCHAR(255) NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    sort_order INT NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_tutors_slug (slug),
    KEY idx_tutors_active_sort (is_active, sort_order, display_name)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tutor_competencies (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    tutor_id INT UNSIGNED NOT NULL,
    category ENUM('fach','methodik','didaktik','faehigkeit','qualifikation') NOT NULL,
    title VARCHAR(190) NOT NULL,
    description TEXT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY idx_tutor_competencies (tutor_id, category, sort_order)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO tutors
(slug, display_name, professional_title, short_intro, biography, teaching_approach, image_path, image_alt, is_active, sort_order)
VALUES
('olaf-thiele', 'Olaf Thiele', 'Tutor für Mathematik, Physik, Chemie und Informatik',
 'Fachübergreifende Lernbegleitung für Schule, Ausbildung, Abitur und Studium.',
 'Olaf Thiele verbindet mathematisches, naturwissenschaftliches und informatisches Denken. Im Unterricht werden Zusammenhänge sichtbar gemacht, statt einzelne Verfahren nur auswendig zu lernen.',
 'Ausgangspunkt ist immer der aktuelle Denkweg des Lernenden. Begriffe werden geklärt, Lösungswege schriftlich strukturiert, Fehler als Diagnose genutzt und Ergebnisse anschließend selbstständig überprüft.',
 'assets/img/tutors/olaf-thiele.svg', 'Porträtgrafik von Olaf Thiele', 1, 10),
('sprachentutorin', 'Sprachentutorin', 'Tutorin für Deutsch, Englisch, Französisch, Spanisch und Latein',
 'Sprachliche Sicherheit durch verständliche Grammatik, aktiven Wortschatz und adressatengerechten Ausdruck.',
 'Der Sprachunterricht verbindet systematischen Aufbau mit konkreter Anwendung. Lesen, Schreiben, Sprechen und Sprachreflexion werden passend zum Lernstand miteinander verknüpft.',
 'Neue Strukturen werden an Beispielen eingeführt, gemeinsam angewendet und in kleinen Übungsschritten gesichert. Rückmeldungen zeigen nicht nur Fehler, sondern erklären, wie eine bessere Formulierung entsteht.',
 'assets/img/tutors/sprachentutorin.svg', 'Porträtgrafik einer Sprachentutorin', 1, 20),
('ethiktutor', 'Tutor für Ethik', 'Tutor für Ethik, Philosophie und gesellschaftliche Fragestellungen',
 'Argumentieren lernen, Positionen prüfen und eigene Urteile nachvollziehbar begründen.',
 'Der Ethikunterricht erschließt Begriffe, Konflikte und philosophische Positionen. Unterschiedliche Sichtweisen werden sachlich verglichen und auf konkrete Lebens- und Prüfungssituationen bezogen.',
 'Diskussionen werden durch Leitfragen, Begriffsarbeit und Argumentationsmodelle strukturiert. Ziel ist kein vorgegebenes Urteil, sondern eine fachlich begründete, sprachlich klare und reflektierte Position.',
 'assets/img/tutors/ethiktutor.svg', 'Porträtgrafik eines Tutors für Ethik', 1, 30)
ON DUPLICATE KEY UPDATE
 professional_title=VALUES(professional_title), short_intro=VALUES(short_intro), biography=VALUES(biography),
 teaching_approach=VALUES(teaching_approach), image_path=VALUES(image_path), image_alt=VALUES(image_alt),
 is_active=VALUES(is_active), sort_order=VALUES(sort_order);

DELETE tc FROM tutor_competencies tc
INNER JOIN tutors t ON t.id = tc.tutor_id
WHERE t.slug IN ('olaf-thiele','sprachentutorin','ethiktutor');

INSERT INTO tutor_competencies (tutor_id, category, title, description, sort_order)
SELECT id, 'fach', 'Mathematik', 'Grundlagen, Analysis, Algebra, Geometrie, Stochastik und anwendungsbezogene Modellierung.', 10 FROM tutors WHERE slug='olaf-thiele'
UNION ALL SELECT id, 'fach', 'Physik', 'Mechanik, Elektrizitätslehre, Optik, Thermodynamik und moderne Physik.', 20 FROM tutors WHERE slug='olaf-thiele'
UNION ALL SELECT id, 'fach', 'Chemie', 'Stoffaufbau, Reaktionsgleichungen, Stöchiometrie, organische und physikalische Chemie.', 30 FROM tutors WHERE slug='olaf-thiele'
UNION ALL SELECT id, 'fach', 'Informatik', 'Algorithmisches Denken, Programmierung, Datenbanken und technische Grundlagen.', 40 FROM tutors WHERE slug='olaf-thiele'
UNION ALL SELECT id, 'methodik', 'Schriftlich strukturierte Lösungswege', 'Jeder Lösungsweg wird so dokumentiert, dass Annahmen, Teilschritte und Kontrollen nachvollziehbar bleiben.', 10 FROM tutors WHERE slug='olaf-thiele'
UNION ALL SELECT id, 'didaktik', 'Fachübergreifende Verknüpfung', 'Mathematische, naturwissenschaftliche und informatische Zusammenhänge werden gezielt miteinander verbunden.', 20 FROM tutors WHERE slug='olaf-thiele'
UNION ALL SELECT id, 'faehigkeit', 'Diagnose von Denkfehlern', 'Fehler werden nicht nur korrigiert, sondern auf Begriffs-, Verfahrens- oder Verständnislücken zurückgeführt.', 30 FROM tutors WHERE slug='olaf-thiele'
UNION ALL SELECT id, 'qualifikation', 'Studien- und Berufserfahrung im technischen Umfeld', 'Breite technische Perspektive für schulische und studienbezogene Problemstellungen.', 40 FROM tutors WHERE slug='olaf-thiele'

UNION ALL SELECT id, 'fach', 'Deutsch', 'Grammatik, Rechtschreibung, Textanalyse, Erörterung und adressatengerechtes Schreiben.', 10 FROM tutors WHERE slug='sprachentutorin'
UNION ALL SELECT id, 'fach', 'Englisch', 'Wortschatz, Grammatik, Textproduktion, Lese- und Hörverstehen sowie Prüfungskommunikation.', 20 FROM tutors WHERE slug='sprachentutorin'
UNION ALL SELECT id, 'fach', 'Französisch, Spanisch und Latein', 'Sprachsystem, Übersetzung, Ausdruck, Textverständnis und kontinuierlicher Wortschatzaufbau.', 30 FROM tutors WHERE slug='sprachentutorin'
UNION ALL SELECT id, 'methodik', 'Sprachhandeln in kleinen Schritten', 'Neue Strukturen werden erklärt, modelliert, angewendet und anschließend in freien Aufgaben gesichert.', 10 FROM tutors WHERE slug='sprachentutorin'
UNION ALL SELECT id, 'didaktik', 'Fehlersensible Rückmeldung', 'Korrekturen benennen Regel, Wirkung und konkrete Verbesserungsmöglichkeit.', 20 FROM tutors WHERE slug='sprachentutorin'
UNION ALL SELECT id, 'faehigkeit', 'Differenzierte Ausdrucksförderung', 'Wortschatz und Satzbau werden passend zu Schulform, Aufgabe und individuellem Lernstand entwickelt.', 30 FROM tutors WHERE slug='sprachentutorin'
UNION ALL SELECT id, 'qualifikation', 'Sprachdidaktische Ausrichtung', 'Kompetenzorientierte Verbindung von Grammatik, Textarbeit und kommunikativer Anwendung.', 40 FROM tutors WHERE slug='sprachentutorin'

UNION ALL SELECT id, 'fach', 'Ethik und Philosophie', 'Normen, Werte, Menschenbilder, Argumentationstheorie und ausgewählte philosophische Positionen.', 10 FROM tutors WHERE slug='ethiktutor'
UNION ALL SELECT id, 'fach', 'Gesellschaftliche Konfliktfelder', 'Anwendung ethischer Modelle auf Technik, Umwelt, Verantwortung, Freiheit und Gerechtigkeit.', 20 FROM tutors WHERE slug='ethiktutor'
UNION ALL SELECT id, 'methodik', 'Strukturierte Argumentationsanalyse', 'Behauptung, Begründung, Beispiel, Einwand und Schlussfolgerung werden klar unterschieden.', 10 FROM tutors WHERE slug='ethiktutor'
UNION ALL SELECT id, 'didaktik', 'Perspektivwechsel ohne Beliebigkeit', 'Unterschiedliche Positionen werden offen geprüft und zugleich an fachlichen Kriterien gemessen.', 20 FROM tutors WHERE slug='ethiktutor'
UNION ALL SELECT id, 'faehigkeit', 'Moderation sachlicher Diskussionen', 'Kontroverse Fragen werden wertschätzend, begrifflich präzise und ergebnisoffen bearbeitet.', 30 FROM tutors WHERE slug='ethiktutor'
UNION ALL SELECT id, 'qualifikation', 'Philosophisch-ethische Fachorientierung', 'Sichere Arbeit mit Begriffen, Positionen, Texten und prüfungsrelevanten Urteilsformaten.', 40 FROM tutors WHERE slug='ethiktutor';
